var toast=(function(){"use strict";function S(e){return e}const u=globalThis.browser?.runtime?.id?globalThis.browser:globalThis.chrome;class p{static containerId="cm-toast-container";static lastMessage="";static lastTime=0;static ensureContainer(){let t=document.getElementById(this.containerId);if(!t){t=document.createElement("div"),t.id=this.containerId,t.style.cssText=`
        position: fixed;
        top: 20px;
        right: 20px;
        z-index: 2147483647;
        display: flex;
        flex-direction: column;
        gap: 10px;
        pointer-events: none;
        font-family: 'Inter', -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
      `,document.body.appendChild(t);const n=document.createElement("style");n.textContent=`
        @keyframes cm-toast-in {
          from { transform: translateX(100%); opacity: 0; }
          to { transform: translateX(0); opacity: 1; }
        }
        @keyframes cm-toast-out {
          from { transform: translateX(0); opacity: 1; }
          to { transform: translateX(100%); opacity: 0; }
        }
        .cm-toast {
          background: #1e2329;
          color: #eaecef;
          padding: 12px 18px;
          border-radius: 8px;
          box-shadow: 0 4px 12px rgba(0,0,0,0.3);
          font-size: 14px;
          font-weight: 500;
          min-width: 240px;
          max-width: 320px;
          display: flex;
          align-items: center;
          gap: 12px;
          cursor: pointer;
          pointer-events: auto;
          animation: cm-toast-in 0.3s cubic-bezier(0.4, 0, 0.2, 1);
          border-left: 4px solid #f0b90b;
        }
        .cm-toast.success { border-left-color: #0ecb81; }
        .cm-toast.error { border-left-color: #f6465d; }
        .cm-toast.info { border-left-color: #f0b90b; }
        .cm-toast.out {
          animation: cm-toast-out 0.3s cubic-bezier(0.4, 0, 0.2, 1) forwards;
        }
        .cm-toast-icon {
          font-size: 18px;
          display: flex;
          align-items: center;
          justify-content: center;
        }
        .cm-toast-content {
          flex: 1;
        }
      `,document.head.appendChild(n)}return t}static show(t,n="info",i=3e3){const s=Date.now();if(t===this.lastMessage&&s-this.lastTime<1e3)return;this.lastMessage=t,this.lastTime=s;const r=this.ensureContainer(),o=document.createElement("div");o.className=`cm-toast ${n}`;let d="🔔";n==="success"&&(d="✅"),n==="error"&&(d="❌"),n==="info"&&(d="🔄"),o.innerHTML=`
      <div class="cm-toast-icon">${d}</div>
      <div class="cm-toast-content">${t}</div>
    `,r.appendChild(o);const f=()=>{o.classList.add("out"),setTimeout(()=>{o.parentNode===r&&r.removeChild(o)},300)};o.onclick=f,i>0&&setTimeout(f,i)}}const g={matches:["<all_urls>"],runAt:"document_start",main(){u.runtime.onMessage.addListener(e=>{if(e.type==="SHOW_TOAST"){let t=e.message||e.text,n=e.toastType||"info",i=e.duration||3e3;!t&&e.action&&e.captchaType&&(e.action==="solving"?(t=`Solving ${e.captchaType}...`,n="info"):e.action==="solved"&&(t=`${e.captchaType} Solved!`,n="success",i=4e3)),t&&p.show(t,n,i)}})}};function a(e,...t){}const v={debug:(...e)=>a(console.debug,...e),log:(...e)=>a(console.log,...e),warn:(...e)=>a(console.warn,...e),error:(...e)=>a(console.error,...e)};class h extends Event{constructor(t,n){super(h.EVENT_NAME,{}),this.newUrl=t,this.oldUrl=n}static EVENT_NAME=m("wxt:locationchange")}function m(e){return`${u?.runtime?.id}:toast:${e}`}function b(e){let t,n;return{run(){t==null&&(n=new URL(location.href),t=e.setInterval(()=>{let i=new URL(location.href);i.href!==n.href&&(window.dispatchEvent(new h(i,n)),n=i)},1e3))}}}class c{constructor(t,n){this.contentScriptName=t,this.options=n,this.abortController=new AbortController,this.isTopFrame?(this.listenForNewerScripts({ignoreFirstEvent:!0}),this.stopOldScripts()):this.listenForNewerScripts()}static SCRIPT_STARTED_MESSAGE_TYPE=m("wxt:content-script-started");isTopFrame=window.self===window.top;abortController;locationWatcher=b(this);receivedMessageIds=new Set;get signal(){return this.abortController.signal}abort(t){return this.abortController.abort(t)}get isInvalid(){return u.runtime.id==null&&this.notifyInvalidated(),this.signal.aborted}get isValid(){return!this.isInvalid}onInvalidated(t){return this.signal.addEventListener("abort",t),()=>this.signal.removeEventListener("abort",t)}block(){return new Promise(()=>{})}setInterval(t,n){const i=setInterval(()=>{this.isValid&&t()},n);return this.onInvalidated(()=>clearInterval(i)),i}setTimeout(t,n){const i=setTimeout(()=>{this.isValid&&t()},n);return this.onInvalidated(()=>clearTimeout(i)),i}requestAnimationFrame(t){const n=requestAnimationFrame((...i)=>{this.isValid&&t(...i)});return this.onInvalidated(()=>cancelAnimationFrame(n)),n}requestIdleCallback(t,n){const i=requestIdleCallback((...s)=>{this.signal.aborted||t(...s)},n);return this.onInvalidated(()=>cancelIdleCallback(i)),i}addEventListener(t,n,i,s){n==="wxt:locationchange"&&this.isValid&&this.locationWatcher.run(),t.addEventListener?.(n.startsWith("wxt:")?m(n):n,i,{...s,signal:this.signal})}notifyInvalidated(){this.abort("Content script context invalidated"),v.debug(`Content script "${this.contentScriptName}" context invalidated`)}stopOldScripts(){window.postMessage({type:c.SCRIPT_STARTED_MESSAGE_TYPE,contentScriptName:this.contentScriptName,messageId:Math.random().toString(36).slice(2)},"*")}verifyScriptStartedEvent(t){const n=t.data?.type===c.SCRIPT_STARTED_MESSAGE_TYPE,i=t.data?.contentScriptName===this.contentScriptName,s=!this.receivedMessageIds.has(t.data?.messageId);return n&&i&&s}listenForNewerScripts(t){let n=!0;const i=s=>{if(this.verifyScriptStartedEvent(s)){this.receivedMessageIds.add(s.data.messageId);const r=n;if(n=!1,r&&t?.ignoreFirstEvent)return;this.notifyInvalidated()}};addEventListener("message",i),this.onInvalidated(()=>removeEventListener("message",i))}}function E(){}function l(e,...t){}const w={debug:(...e)=>l(console.debug,...e),log:(...e)=>l(console.log,...e),warn:(...e)=>l(console.warn,...e),error:(...e)=>l(console.error,...e)};return(async()=>{try{const{main:e,...t}=g,n=new c("toast",t);return await e(n)}catch(e){throw w.error('The content script "toast" crashed on startup!',e),e}})()})();
toast;